Date Repeat Field
-----------------
Creates the option of repeating date fields and manages Date fields that use
the Date Repeat API.
